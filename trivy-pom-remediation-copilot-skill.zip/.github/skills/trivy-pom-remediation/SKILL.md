---
name: trivy-pom-remediation
description: Use this skill whenever the user wants to fix Trivy/dependency-check vulnerabilities found in a Kotlin/Java Maven project's pom.xml, especially before a release deploy gate. Trigger on mentions of "trivy", "dependency check", "security scan", "CVE", "vulnerability report", ".html scan report" combined with pom.xml/Maven/Spring Boot projects. Also trigger when the user wants to reproduce a server-generated Trivy HTML report locally, compare a local scan against a server report, or decide which CVEs (Critical/High/Medium) to remediate before release. Always list findings and get the user's severity scope choice BEFORE editing any pom.xml.
---

# Trivy → pom.xml Remediation (Kotlin/Maven/Spring Boot)

A workflow for triaging Trivy vulnerability findings in a Maven project and
safely patching `pom.xml`, without ever bumping the Spring Boot version and
without silently "fixing" things the user hasn't approved.

## Hard constraints (never violate)

1. **Never change the Spring Boot version.** Do not touch `<parent>`
   version, `spring-boot-starter-parent`, or any property that controls it
   (e.g. `spring.boot.version`). If a fix for a CVE *requires* bumping Spring
   Boot (because the vulnerable lib is pinned by the Spring Boot BOM and
   can't be overridden safely), do NOT apply it — put it in the manual
   review list instead (see Step 4).
2. **Never edit pom.xml before the user has seen the findings list and
   chosen a severity scope.** Step 1 and Step 2 always come before Step 3.
3. **Every skipped/rejected item needs a one-line reason** in the output
   report — nothing should silently disappear.

## Workflow

### Step 0 — Establish the scan profile (do this once per repo)

To make local scans match the server's HTML report, find and record:
- Trivy version used by the pipeline (check Jenkinsfile / `.gitlab-ci.yml` /
  shared groovy library for the `trivy` stage; the exact command is often
  printed in a past build's console log — that's the fastest source of truth)
- Template used (`@contrib/html.tpl` default, or a custom `.tpl` kept in an
  infra repo)
- Scanners/target used (`fs` vs `image` vs `repo`, `--scanners vuln` etc.)
- Severity filter used, if any (`--severity HIGH,CRITICAL` etc. — note if
  the server report actually includes MEDIUM/LOW too, since some pipelines
  filter them out of the gate but still show them in the HTML)

Save these as a small profile, e.g. `.trivy-scan-profile` in the repo root,
so future runs don't need to re-derive this. See
`references/local-scan-setup.md` for the exact commands and troubleshooting
for "local output doesn't match server HTML" (version mismatch, template
mismatch, target mismatch — in that order of likelihood).

### Step 1 — Scan and list (no edits yet)

Run Trivy against the project (JSON output is easiest to parse):

```bash
trivy fs --scanners vuln --format json -o trivy-report.json .
```

If the user already has a server-generated HTML report, parse that instead
of re-scanning — see `references/report-parsing.md` for how to extract the
same fields from either JSON or the two-part HTML (summary section +
bottom table).

Cross-reference each finding against `mvn dependency:tree` to mark it
direct vs. transitive, and check whether it's covered by an existing
`.trivyignore` / suppression file (skip those, note them as "already
suppressed" in the report).

Present a table like this before doing anything else:

| # | Severity | Library | Current | Fixed Version | Direct/Transitive | Requires Spring Boot bump? |
|---|----------|---------|---------|----------------|--------------------|------------------------------|
| 1 | CRITICAL | ...     | ...     | ...            | direct             | no                           |
| 2 | HIGH     | ...     | ...     | ...            | transitive         | no                           |
| 3 | MEDIUM   | ...     | ...     | ...            | direct             | yes — flagged, not auto-fixed|

Include a count summary at the top (e.g. "3 Critical, 5 High, 4 Medium, 2
already suppressed").

### Step 2 — Ask the user what to fix

Never assume scope. Ask (or use `ask_user_input_v0` if available in-chat):
- Fix Critical + High only?
- Include Medium too?
- Cherry-pick specific rows (useful when a Medium is a trivial patch bump)?

Anything requiring a Spring Boot bump is excluded from auto-fix regardless
of the answer — always goes to the manual list.

### Step 3 — Apply fixes for the approved scope

For each approved row:
- **Direct dependency, simple version bump**: update the `<version>` (or the
  `<properties>` entry controlling it) directly.
- **Transitive dependency**: prefer adding/adjusting an entry in
  `<dependencyManagement>` in the project's own pom (not Spring Boot's BOM)
  to pin the fixed version; only add it as an explicit direct dependency if
  dependencyManagement isn't picked up (check with `dependency:tree` again
  after the change).
- **Multi-module repo**: bump at the parent's `dependencyManagement` when
  the dependency is shared across modules; only bump in the child pom if
  it's module-specific.
- Never touch anything under the Spring Boot BOM / parent version.

After each batch of changes:

```bash
mvn dependency:tree -Dincludes=<groupId>:<artifactId>   # confirm resolved version
mvn clean install
```

If `mvn clean install` fails, revert just that dependency's change (don't
leave the pom half-modified) and move that row to the manual review list
with the failure reason.

Then start the app and confirm it comes up cleanly (smoke check, plus
existing test suite if available — a clean build is not proof the runtime
behavior is unaffected).

### Step 4 — Manual review list + report

Produce a short report (markdown is fine) with:
- What was fixed (table: lib, old→new version, CVE(s) closed)
- What was skipped and why (Spring Boot bump required / build failed /
  no fixed version available / already suppressed / user deferred)
- Any Medium/Low items left for a future pass

This report is meant to be attached to the PR description so a reviewer
doesn't have to re-derive the diff by hand.

## Reference files

- `references/local-scan-setup.md` — exact Trivy commands, how to match the
  server's HTML template, and the 3 most common causes of local vs. server
  mismatch (trivy version, template, scan target)
- `references/report-parsing.md` — how to extract the findings table from
  Trivy JSON output or from a two-section HTML report
- `references/pom-fix-patterns.md` — direct vs transitive fix patterns,
  multi-module pom placement, and how to check compatibility against the
  Spring Boot BOM without changing it
