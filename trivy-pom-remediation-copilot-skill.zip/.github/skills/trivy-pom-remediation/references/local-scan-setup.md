# Reproducing the server's Trivy HTML report locally

The server's HTML report typically has two parts:
1. **Summary section** (top) — counts by severity, scan target info
2. **Findings table** (bottom) — Library, VulnerabilityID, Severity,
   Installed Version, Fixed Version, Title

If a local run doesn't match, check these in order — they cover the vast
majority of mismatches:

## 1. Trivy version mismatch (most common)

```bash
trivy --version
```

Compare against the version the pipeline uses. The `html.tpl` output
structure has changed across Trivy versions, so even the *same* template
file can render differently. Find the pinned version in the Jenkinsfile /
CI config / Docker image used by the scan stage.

## 2. Template mismatch

Default:
```bash
trivy fs --scanners vuln \
  --format template \
  --template "@contrib/html.tpl" \
  -o report.html \
  .
```

If the server's report doesn't look like Trivy's default template output
(e.g. different layout/branding), the pipeline likely uses a **custom**
`.tpl` file, usually kept in an internal infra/shared-library repo. Search
that repo for `.tpl` files or a `trivy` groovy step that references
`--template`.

## 3. Scan target / scanner mismatch

```bash
trivy fs   ...   # filesystem / pom.xml dependencies
trivy image ...  # includes OS packages — will show more findings
trivy repo  ...  # scans a git repo directly
```

If the server scans `image` but you run `fs` locally, the summary counts
won't match because OS-level packages are missing from the local scan.
Check the pipeline for which subcommand is used.

## 4. Severity filter differences

```bash
--severity HIGH,CRITICAL
```

Some pipelines filter the *gate* to HIGH/CRITICAL but still generate the
HTML with all severities included. If your local severity counts are lower
than the report, check whether `--severity` is being passed at all.

## Fastest way to get the exact command

Rather than reverse-engineering from groovy, open the console log of a
previous build where the scan ran — Trivy's command is almost always
echoed in full there. This is usually faster than digging through
Jenkinsfile / shared library groovy.

## Suggested local profile file

Once confirmed, save it so it doesn't need to be re-derived:

```
# .trivy-scan-profile
TRIVY_VERSION=0.55.0
SCAN_TARGET=fs
TEMPLATE=@contrib/html.tpl   # or path to custom template
SEVERITY=CRITICAL,HIGH,MEDIUM,LOW
EXTRA_FLAGS=--scanners vuln
```

## Offline / limited connectivity tips

Trivy downloads its vulnerability DB on each run by default. If working
with unstable connectivity:

```bash
trivy fs --skip-db-update ...   # reuse previously cached DB
```

Pre-cache the DB when connectivity is good with a plain `trivy fs --scanners vuln .`
run ahead of time.
