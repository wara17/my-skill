# Parsing Trivy findings (JSON or HTML) into the triage table

## From JSON (preferred — run this yourself)

```bash
trivy fs --scanners vuln --format json -o trivy-report.json .
```

Each finding lives under `Results[].Vulnerabilities[]` with fields:
- `PkgName`, `InstalledVersion`, `FixedVersion`
- `VulnerabilityID`, `Severity`, `Title`

A quick extraction with `jq`:

```bash
jq -r '.Results[]?.Vulnerabilities[]? |
  [.Severity, .PkgName, .InstalledVersion, .FixedVersion, .VulnerabilityID] |
  @tsv' trivy-report.json | sort
```

## From a server-provided HTML report (two-section template)

If only the HTML is available (no JSON), the bottom table is the one to
parse — the top summary section is just aggregate counts and isn't needed
for row-level data. Extract table rows (Library / Vulnerability ID /
Severity / Installed Version / Fixed Version / Title) — a simple HTML
table parse (e.g. `pandas.read_html` in Python, or an XML/HTML parser) is
sufficient since Trivy's default template uses plain `<table>` markup.

## Cross-referencing with dependency:tree

For each `PkgName` found, confirm whether it's a direct or transitive
dependency and which module it's under (for multi-module repos):

```bash
mvn dependency:tree -Dincludes=<groupId>:<artifactId>
```

If it doesn't appear in the root pom's own `<dependencies>`, it's
transitive — trace which direct dependency pulls it in from the tree
output (the indentation shows the path).

## Checking for existing suppressions

Before listing something as "needs fix", check whether it's already
acknowledged:

```bash
cat .trivyignore 2>/dev/null
```

Anything listed there should show up in the triage table as "already
suppressed" rather than as an open item — don't re-flag it unless the user
asks to review suppressions too.

## Diffing local vs. server report

To answer "why doesn't my local scan match the report I was given": parse
both into the same normalized table (Severity, PkgName, VulnerabilityID)
and diff on `VulnerabilityID`. Findings only in the server report but not
local usually point to a scan target mismatch (e.g. server scans `image`,
you scanned `fs`). Findings only in local but not server usually mean the
vulnerability DB versions differ (server DB is older/newer).
