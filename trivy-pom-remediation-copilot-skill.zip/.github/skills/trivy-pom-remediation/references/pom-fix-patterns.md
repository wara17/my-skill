# pom.xml fix patterns (never touching Spring Boot version)

## Golden rule

Never edit:
- `<parent><version>...</version></parent>` where the parent is
  `spring-boot-starter-parent`
- Any property like `spring.boot.version` that drives it

If a fix genuinely requires a newer Spring Boot BOM to resolve cleanly,
do NOT apply it. Add it to the manual review list with the reason
"requires Spring Boot bump — excluded by policy".

## Direct dependency, simple bump

If the library is declared directly in `<dependencies>`, just bump its
`<version>` (or the `<properties>` entry that controls it) to the fixed
version reported by Trivy. Re-run:

```bash
mvn dependency:tree -Dincludes=<groupId>:<artifactId>
mvn clean install
```

## Transitive dependency

Prefer pinning via the project's own `<dependencyManagement>` (not
touching Spring Boot's BOM):

```xml
<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>...</groupId>
      <artifactId>...</artifactId>
      <version><!-- fixed version --></version>
    </dependency>
  </dependencies>
</dependencyManagement>
```

Verify the resolved version actually changed:

```bash
mvn dependency:tree -Dincludes=<groupId>:<artifactId>
```

If dependencyManagement alone doesn't force it (some plugin-managed or
BOM-imported deps resist this), add it as an explicit direct dependency
instead, or use an `<exclusion>` on the parent that pulls it in plus a
fresh direct dependency at the fixed version.

## Multi-module projects

- If multiple modules use the same dependency → bump in the **parent**
  pom's `<dependencyManagement>` once.
- If it's specific to one module → bump only in that module's pom.
- Always re-check `dependency:tree` per affected module, not just the
  module you edited — version resolution can differ across modules.

## Checking compatibility against the Spring Boot BOM (without editing it)

Before bumping, check what version Spring Boot's BOM
(`spring-boot-dependencies` for the project's current Spring Boot version)
already pins for that library. If the desired fixed version is a
patch/minor step within the same major line as the BOM's version, it's
usually safe. If it's a major-version jump, flag for manual review even if
it's technically possible to force — cross-major bumps risk breaking
changes without a corresponding Spring Boot upgrade to match.

## If `mvn clean install` fails after a bump

- Revert only that dependency's change — don't leave a half-modified pom.
- Move the row to the manual review list with the actual build error
  (not just "failed") so a human doesn't have to re-run it blind.

## Verifying the app still starts

A clean build is not sufficient proof. After all approved fixes are
applied in a batch:

```bash
mvn clean install
# then start the app per the project's normal run command and confirm
# it comes up without errors, plus run the existing test suite if present
```
